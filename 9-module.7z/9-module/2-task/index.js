import Carousel from '../../6-module/3-task/index.js';
import slides from '../../6-module/3-task/slides.js';

import RibbonMenu from '../../7-module/1-task/index.js';
import categories from '../../7-module/1-task/categories.js';

import StepSlider from '../../7-module/4-task/index.js';
import ProductsGrid from '../../8-module/2-task/index.js';

import CartIcon from '../../8-module/1-task/index.js';
import Cart from '../../8-module/4-task/index.js';

export default class Main {
  #carousel = new Carousel(slides);
  #ribbonMenu = new RibbonMenu(categories);

  #stepSlider = new StepSlider({
    steps: 5,
    value: 3
  });

  #cartIcon = new CartIcon();
  #cart = new Cart(this.#cartIcon);

  #productsGrid = null;

  constructor() {
    document.querySelector("[data-carousel-holder]").appendChild(this.#carousel.elem);
    document.querySelector("[data-ribbon-holder]").appendChild(this.#ribbonMenu.elem);
    document.querySelector("[data-slider-holder]").appendChild(this.#stepSlider.elem);
    document.querySelector("[data-cart-icon-holder]").appendChild(this.#cartIcon.elem);
  }

  async render() {
    const products = await fetch("products.json").then(res => res.json());
    
    this.#productsGrid = new ProductsGrid(products);
    document.querySelector("[data-products-grid-holder]").appendChild(this.#productsGrid.elem);
    this.#productsGrid.updateFilter({
      noNuts: document.getElementById("nuts-checkbox").checked,
      vegeterianOnly: document.getElementById("vegeterian-checkbox").checked,
      maxSpiciness: this.#stepSlider.value,
      category: this.#ribbonMenu.value
    });

    document.body.addEventListener("product-add", event => this.#cart.addProduct(products.find(p => p.id === event.detail)));
    document.body.addEventListener("slider-change", event => this.#productsGrid.updateFilter({
      maxSpiciness: event.detail,
    }));
    document.body.addEventListener("ribbon-select", event => this.#productsGrid.updateFilter({
      category: event.detail
    }));

    document.querySelector("#nuts-checkbox").addEventListener("change", event => this.#productsGrid.updateFilter({
      noNuts: event.target.checked
    }));
    document.querySelector("#vegeterian-checkbox").addEventListener("change", event => this.#productsGrid.updateFilter({
      vegeterianOnly: event.target.checked
    }));
  }
}
